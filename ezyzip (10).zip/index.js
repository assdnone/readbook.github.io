(function() {
	var nav = $('nav'),
	menu = $('nav h1'),
	main = $('main');

	menu.on('click', function() {
		nav.toggleClass('menu-active');
		main.toggleClass('menu-active');
		nav.removeClass('menu-hover');
		main.removeClass('menu-hover');
	});
})();